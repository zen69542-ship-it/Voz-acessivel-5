# Roteiro de apresentação — Convive (Feira Tecnológica 2026)

A equipe está dividida em dois grupos. Os dois cobrem os **mesmos assuntos**, na mesma
ordem — assim qualquer um dos dois grupos consegue apresentar sozinho, sem depender
do outro estar disponível no dia.

Frases curtas, ação concreta antes da fala. O que trava mais é decorar frase longa —
o que importa é apontar na tela e dizer o que está acontecendo.

Duração alvo por grupo: 5 a 7 minutos de fala + perguntas.

---

## Grupo 1 — Lukas, Blumenthal, Iza, Emanuel

### 1. Abertura e o problema — Iza
**Ação:** abre a home (`index.html`), estado padrão.
**Fala:**
> "O Convive resolve um problema simples: sites comuns têm barreiras pra quem é
> surdo, tem baixa visão ou dificuldade motora. Segundo a OMS, isso afeta 15% da
> população mundial — quase 1 bilhão de pessoas."

### 2. Painel de acessibilidade e perfis — Blumenthal
**Ação:** clica no botão flutuante de acessibilidade → clica no perfil "Baixa visão".
**Fala:**
> "Isso aqui não é decoração. É um painel real. Ativando o perfil 'Baixa visão',
> a interface muda agora: contraste alto, cursor maior, fonte maior — tudo de uma vez."

### 3. Persistência e Libras — Lukas
**Ação:** recarrega a página (F5) → mostra que o perfil continua ativo → abre o botão de Libras.
**Fala:**
> "Essa escolha fica salva no navegador da pessoa. E pra quem usa Libras, temos
> dois caminhos: um painel próprio, feito por nós, e o VLibras, o tradutor oficial
> do Governo Federal."

### 4. Leitura em voz alta — Lukas
**Ação:** clica em "Ouvir esta página" → depois clica em um parágrafo específico.
**Fala:**
> "A página inteira pode ser ouvida em voz alta. E dá pra clicar em qualquer
> parágrafo pra ouvir só aquele trecho, sem escutar tudo de novo."

### 5. Como fizemos isso — Emanuel
**Ação:** abre `tecnologia.html`, mostra o diagrama de fluxo.
**Fala:**
> "Por trás de cada botão: HTML marca o que o botão controla, JavaScript aplica
> uma classe na página, o CSS já tem a regra pronta pra essa classe, e a escolha
> é salva no localStorage do navegador. Sem servidor."

### 6. Como testamos e limitações — Emanuel
**Ação:** mostra a seção "Como testamos" em `tecnologia.html`.
**Fala:**
> "A gente verificou teclado, foco visível, contraste, daltonismo e zoom com as
> próprias mãos. O que ainda não fizemos é testar com pessoas que realmente usam
> essas tecnologias — e falamos isso abertamente no site, sem inventar validação."

### 7. Fechamento — Iza
**Ação:** volta pro estado padrão (botão "Restaurar tudo" no painel).
**Fala:**
> "É isso que quisemos trazer pra feira: não um site falando sobre acessibilidade,
> mas recursos que funcionam de verdade, agora, nesta tela."

---

## Grupo 2 — Rafael, Pietro, Enzo

### 1. Abertura e o problema — Rafael
**Ação:** abre a home (`index.html`), estado padrão.
**Fala:**
> "O Convive resolve um problema simples: sites comuns têm barreiras pra quem é
> surdo, tem baixa visão ou dificuldade motora. Segundo o Censo 2022 do IBGE, são
> 14,4 milhões de pessoas só no Brasil."

### 2. Painel de acessibilidade e perfis — Pietro
**Ação:** clica no botão flutuante de acessibilidade → clica no perfil "Mobilidade reduzida".
**Fala:**
> "O painel é real, não decorativo. Ativando 'Mobilidade reduzida', os botões da
> página ficam maiores e mais espaçados na hora — pra quem tem dificuldade de
> precisão motora."

### 3. Persistência e Libras — Enzo
**Ação:** recarrega a página (F5) → mostra que o perfil continua ativo → abre o botão de Libras.
**Fala:**
> "Essa escolha fica salva no navegador. E o site tem dois caminhos pra Libras:
> um painel próprio nosso, e o VLibras, tradutor oficial do Governo Federal."

### 4. Leitura em voz alta — Pietro
**Ação:** clica em "Ouvir esta página" → depois clica em um parágrafo específico.
**Fala:**
> "A página inteira pode ser ouvida em voz alta, ou só um parágrafo específico —
> é só clicar nele."

### 5. Como fizemos isso — Enzo
**Ação:** abre `tecnologia.html`, mostra o diagrama de fluxo.
**Fala:**
> "O caminho é sempre o mesmo: HTML marca o botão, JavaScript aplica uma classe,
> o CSS reage a essa classe, e a preferência é salva no localStorage do navegador."

### 6. Como testamos e limitações — Enzo
**Ação:** mostra a seção "Como testamos" em `tecnologia.html`.
**Fala:**
> "Verificamos teclado, foco, contraste e daltonismo nós mesmos. Ainda não
> testamos com usuários reais — e preferimos dizer isso do que inventar validação."

### 7. Fechamento — Rafael
**Ação:** volta pro estado padrão (botão "Restaurar tudo" no painel).
**Fala:**
> "O Convive não é um site que fala sobre acessibilidade. É um site que a
> demonstra, funcionando de verdade."

---

## Perguntas prováveis da banca
- "Isso funciona em celular?" → sim, todo o painel e os recursos são responsivos.
- "Testaram com alguém que usa leitor de tela de verdade?" → não ainda — resposta
  honesta, ninguém deve inventar que sim.
- "Por que Libras e não outro recurso?" → é exigência legal (LBI, Decreto 5.626/2005)
  e afeta uma população real (2,6 milhões de brasileiros, Censo 2022).
- "O que vocês fariam com mais tempo?" → testes reais de acessibilidade e mais
  perfis combinados.
